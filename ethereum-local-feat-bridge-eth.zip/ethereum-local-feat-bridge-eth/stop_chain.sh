#!/bin/bash

echo "Stopping Ethereum local chain..."

# Stop the containers
if docker-compose down; then
    echo "Containers stopped successfully"
else
    echo "Error: Failed to stop containers"
    exit 1
fi

# Ask for confirmation before deleting data
read -p "Do you want to delete all blockchain data? This cannot be undone! (y/N) " -n 1 -r
echo
if [[ $REPLY =~ ^[Yy]$ ]]; then
    echo "Removing blockchain data..."
    if rm -rf data; then
        echo "Blockchain data removed successfully"
    else
        echo "Error: Failed to remove blockchain data"
        exit 1
    fi
else
    echo "Keeping blockchain data"
fi

echo "Cleanup complete!"
