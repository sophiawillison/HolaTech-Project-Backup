const { ethers } = require("hardhat");

async function main() {
    try {
        // Get node info
        const nodeInfo = await ethers.provider.send("web3_clientVersion", []);
        console.log("Node Version:", nodeInfo);

        // Get sync status
        const syncStatus = await ethers.provider.send("eth_syncing", []);
        console.log("\nSync Status:", syncStatus);

        // Get node type
        const nodeType = await ethers.provider.send("debug_nodeType", []);
        console.log("\nNode Type:", nodeType);

        // Get node config
        const nodeConfig = await ethers.provider.send("debug_nodeConfig", []);
        console.log("\nNode Config:", nodeConfig);

        // Check if node is archive node
        const blockNumber = await ethers.provider.getBlockNumber();
        const oldBlock = await ethers.provider.getBlock(blockNumber - 1000);
        console.log("\nCan access old blocks:", oldBlock ? "Yes (Archive Node)" : "No (Not Archive Node)");

    } catch (error) {
        console.error("Error:", error.message);
    }
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    }); 
