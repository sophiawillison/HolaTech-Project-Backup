const { ethers } = require("hardhat");
const RLP = require('rlp');
const FeeMarketEIP1559Transaction = require('@ethereumjs/tx').FeeMarketEIP1559Transaction;
const AccessListEIP2930Transaction = require('@ethereumjs/tx').AccessListEIP2930Transaction;
const LegacyTransaction = require('@ethereumjs/tx').LegacyTransaction;
const { toBuffer } = require('@ethereumjs/util');
const { TransactionFactory } = require('@ethereumjs/tx');

async function main() {
  console.log('Current network:', await ethers.provider.getNetwork());
    // Transaction hash của giao dịch - thay bằng transaction hash thực tế của bạn
    const txHash = "0x2b766fd064ce13e2955e93aca30011f172b5690790509423f11ed00cedf56722";

    try {
        console.log(`Đang lấy thông tin cho transaction ${txHash}...`);
        
        // Đợi transaction được mine nếu chưa có transactionIndex
        let receipt = await ethers.provider.getTransactionReceipt(txHash);
        console.log(receipt);
        let maxTries = 30; // tối đa 1 phút
        while ((!receipt || typeof receipt.index !== 'number') && maxTries > 0) {
            console.log('Transaction chưa được mine, đang chờ...');
            await new Promise(resolve => setTimeout(resolve, 2000));
            receipt = await ethers.provider.getTransactionReceipt(txHash);
            maxTries--;
        }
        if (!receipt || typeof receipt.index !== 'number') {
            throw new Error('Transaction index is undefined. Transaction may not be mined yet.');
        }
        
        // Lấy transaction
        const tx = await ethers.provider.getTransaction(txHash);
        if (!tx) {
            throw new Error(`Không tìm thấy transaction với hash ${txHash}`);
        }
        
        // Lấy block
        const block = await ethers.provider.getBlock(tx.blockNumber);
        if (!block) {
            throw new Error(`Không tìm thấy block ${tx.blockNumber}`);
        }
        
        console.log(`Block number: ${block.number}`);
        console.log(`Block hash: ${block.hash}`);
        console.log(`Transaction index: ${receipt.index}`);
        
        const latestBlock = await ethers.provider.getBlockNumber();
        console.log('Latest block:', latestBlock);
    
        
        // 1. Lấy raw transaction bytes
        let rawTx;
        
        if (tx.type === 2) {
            // EIP-1559
            const txData = {
                chainId: tx.chainId,
                nonce: tx.nonce,
                maxPriorityFeePerGas: tx.maxPriorityFeePerGas,
                maxFeePerGas: tx.maxFeePerGas,
                gasLimit: tx.gasLimit,
                to: tx.to,
                value: tx.value,
                data: tx.data || '0x',
                accessList: tx.accessList || [],
                v: tx.v,
                r: tx.r,
                s: tx.s
            };
            const txObj = TransactionFactory.fromTxData(txData);
            rawTx = txObj.serialize().toString('hex');
        } else if (tx.type === 1) {
            // EIP-2930
            const txData = {
                chainId: tx.chainId,
                nonce: tx.nonce,
                gasPrice: tx.gasPrice,
                gasLimit: tx.gasLimit,
                to: tx.to,
                value: tx.value,
                data: tx.data || '0x',
                accessList: tx.accessList || [],
                v: tx.v,
                r: tx.r,
                s: tx.s
            };
            const txObj = AccessListEIP2930Transaction.fromTxData(txData);
            rawTx = txObj.serialize().toString('hex');
        } else {
            // Legacy
            const txData = {
                chainId: tx.chainId,
                nonce: tx.nonce,
                gasPrice: tx.gasPrice,
                gasLimit: tx.gasLimit,
                to: tx.to,
                value: tx.value,
                data: tx.data || '0x',
                v: tx.v,
                r: tx.r,
                s: tx.s
            };
            const txObj = LegacyTransaction.fromTxData(txData);
            rawTx = txObj.serialize().toString('hex');
        }
        
        // Đảm bảo rawTx không có prefix 0x
        if (rawTx.startsWith('0x')) {
            rawTx = rawTx.slice(2);
        }
        
        // 2. Tạo raw receipt đơn giản
        console.log('Đang tạo raw receipt...');
        
        // Tạo receipt object theo định dạng của Ethereum
        const receiptItems = [
            receipt.status ? '0x01' : '0x00',  // status: 1 byte
            ethers.utils.hexValue(receipt.cumulativeGasUsed),  // cumulativeGasUsed
            receipt.logsBloom,  // logsBloom: 256 bytes
            
            // Chuyển đổi logs thành định dạng RLP
            receipt.logs.map(log => [
                log.address,
                log.topics,
                log.data
            ])
        ];
        
        // RLP encode receipt
        const rawReceiptRlp = RLP.encode(receiptItems);
        const rawReceiptHex = Buffer.from(rawReceiptRlp).toString('hex');
        
        // 3. Tạo Merkle proof path đơn giản
        // Đối với một phiên bản đơn giản hơn, chúng ta sẽ sử dụng một mảng trống
        // hoặc sử dụng các transaction hash từ block làm path
        console.log('Đang tạo path đơn giản...');
        
        // Lấy tất cả transaction hash trong block
        const txHashes = block.transactions;
        
        // Tạo path đơn giản từ các transaction hash
        // (đây không phải là Merkle proof thực sự, nhưng sẽ đủ cho mục đích của chúng ta)
        const path = [];
        for (let i = 0; i < txHashes.length; i++) {
            if (i !== receipt.index) { // Loại bỏ transaction của chúng ta
                const hash = txHashes[i];
                if (typeof hash === 'string' && hash.startsWith('0x')) {
                    path.push(hash);
                }
            }
        }
        
        // 4. Tạo proof object
        const proofObject = {
            blockHash: block.hash,
            txIndex: receipt.index,
            receipt: '0x' + rawReceiptHex,
            path: path,
            tx: '0x' + rawTx
        };
        
        console.log('Proof object đã được tạo');
        
        // 5. RLP encode toàn bộ proof object
        console.log('Đang RLP encode proof object...');
        
        // Chuyển đổi các dữ liệu hex thành Buffer
        const blockHashBuffer = hexToBuffer(proofObject.blockHash);
        const txBuffer = hexToBuffer('0x' + rawTx);
        const receiptBuffer = hexToBuffer('0x' + rawReceiptHex);
        const pathBuffers = proofObject.path.map(p => hexToBuffer(p));
        
        // Tạo mảng để RLP encode
        const rlpArray = [
            blockHashBuffer,
            proofObject.txIndex,
            receiptBuffer,
            pathBuffers,
            txBuffer
        ];
        
        // RLP encode
        const rlpEncoded = RLP.encode(rlpArray);
        
        // Base64 encode kết quả RLP
        const base64Encoded = Buffer.from(rlpEncoded).toString('base64');
        
        // Đặt trong mảng 1 phần tử như yêu cầu
        const proofStrs = [base64Encoded];
        
        console.log('ProofStrs đã được tạo thành công!');
        
        // Tạo final proof object
        const finalProof = {
            ProofStrs: proofStrs,
            BlockHash: block.hash,
            BlockNumber: block.number,
            TransactionHash: txHash,
            TransactionIndex: receipt.index,
            From: receipt.from,
            To: receipt.to,
            Value: tx.value.toString(),
            GasUsed: receipt.gasUsed.toString(),
            Status: receipt.status === 1 ? "Success" : "Failed"
        };
        
        // Lưu proof vào file
        const fs = require('fs');
        fs.writeFileSync('deposit_proof.json', JSON.stringify(finalProof, null, 2));
        
        console.log("Deposit proof đã được lưu vào file deposit_proof.json");
        console.log("\nThông tin proof:");
        console.log("Block Number:", finalProof.BlockNumber);
        console.log("Block Hash:", finalProof.BlockHash);
        console.log("Transaction Hash:", finalProof.TransactionHash);
        console.log("From:", finalProof.From);
        console.log("To:", finalProof.To);
        console.log("Value:", ethers.utils.formatEther(finalProof.Value), "ETH");
        console.log("Gas Used:", finalProof.GasUsed);
        console.log("Status:", finalProof.Status);
        console.log("\nProof Strings:");
        console.log(JSON.stringify(finalProof.ProofStrs, null, 2));

    } catch (error) {
        console.error("Error:", error.message);
        console.error(error.stack);
    }
}

/**
 * Chuyển đổi chuỗi hex thành Buffer
 * @param {string} hex - Chuỗi hex
 * @returns {Buffer} - Buffer
 */
function hexToBuffer(hex) {
    // Loại bỏ '0x' nếu có
    if (hex.startsWith('0x')) {
        hex = hex.slice(2);
    }
    
    // Đảm bảo độ dài chẵn
    if (hex.length % 2 !== 0) {
        hex = '0' + hex;
    }
    
    return Buffer.from(hex, 'hex');
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    });
