const { ethers } = require("hardhat");

async function main() {
    // Get the signer (account) that will make the deposit
    const [signer] = await ethers.getSigners();
    console.log("Using account:", signer.address);

    // The address of your deployed Vault contract
    const VAULT_ADDRESS = "0x8b9176b7B001C254F45330E1Fb24b84fE4B80d6b"; // Replace with your deployed contract address

    // Get the Vault contract instance
    const Vault = await ethers.getContractFactory("Vault");
    const vault = await Vault.attach(VAULT_ADDRESS);

    // The Incognito address that will receive pETH
    const incognitoAddress = "12sendKRF5JXTSzFoHNS4JdtWYLcxVshaSwiRTeLRBKv4HDRp3EwrHY5ZWPxcdb9ve5j1pP167M8gHbMBi2ALVzeLynBe5srcUfC48Gsj7osKvLcB2tTNedJqc6vopMkn5ko4yB6juxd97pF7CLw"; // Replace with actual Incognito address

    // Amount of ETH to deposit (in wei)
    const depositAmount = ethers.parseEther("1.0"); // 1 ETH

    console.log("Making deposit...");
    console.log("Amount:", ethers.formatEther(depositAmount), "ETH");
    console.log("Incognito Address:", incognitoAddress);

    try {
        // Make the deposit
        const tx = await vault.deposit(incognitoAddress, {
            value: depositAmount
        });

        console.log("Transaction hash:", tx.hash);
        
        // Wait for transaction to be mined
        const receipt = await tx.wait();
        console.log("Transaction confirmed in block:", receipt.blockNumber);

        // Get the Deposit event
        const depositEvent = receipt.logs[0]; // Assuming Deposit is the first event
        if (depositEvent) {
            const parsedLog = vault.interface.parseLog(depositEvent);
            console.log("Deposit event emitted:");
            console.log("- Token:", parsedLog.args[0]); // token
            console.log("- Incognito Address:", parsedLog.args[1]); // incognitoAddress
            console.log("- Amount:", ethers.formatEther(parsedLog.args[2]), "ETH"); // amount
        }

    } catch (error) {
        console.error("Error making deposit:", error.message);
    }
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    }); 
