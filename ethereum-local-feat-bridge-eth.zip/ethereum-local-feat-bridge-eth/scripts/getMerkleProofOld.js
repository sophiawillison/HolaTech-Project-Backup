const { ethers } = require("hardhat");

async function main() {
    // Transaction hash của deposit transaction
    const txHash = "0x2b766fd064ce13e2955e93aca30011f172b5690790509423f11ed00cedf56722";

    try {
        // Lấy transaction receipt
        const receipt = await ethers.provider.getTransactionReceipt(txHash);
        if (!receipt) {
            throw new Error("Transaction not found");
        }

        // Lấy block
        const block = await ethers.provider.getBlock(receipt.blockNumber);
        if (!block) {
            throw new Error("Block not found");
        }
        
        // Lấy transaction
        const tx = await ethers.provider.getTransaction(txHash);
        if (!tx) {
            throw new Error("Transaction not found");
        }

        // Kiểm tra xem node có hỗ trợ eth_getProof không
        try {
            await ethers.provider.send("eth_getProof", [
                receipt.to,
                [],
                "0x0"
            ]);
        } catch (error) {
            console.error("Node không hỗ trợ eth_getProof hoặc không có đủ dữ liệu state");
            console.error("Hãy đảm bảo rằng bạn đang sử dụng một node đầy đủ (full node)");
            console.error("hoặc một node archive node");
            throw error;
        }

        // Chuyển blockNumber thành hex string
        const blockNumberHex = "0x" + receipt.blockNumber.toString(16);

        console.log("Đang tạo account proof cho block:", receipt.blockNumber);
        console.log("Contract address:", receipt.to);

        // Lấy account proof
        let accountProof;
        let retries = 3;
        while (retries > 0) {
            try {
                accountProof = await ethers.provider.send("eth_getProof", [
                    receipt.to,
                    [],
                    blockNumberHex
                ]);
                break;
            } catch (error) {
                retries--;
                if (retries === 0) throw error;
                console.log(`Retry getting proof... (${3 - retries}/3)`);
                await new Promise(resolve => setTimeout(resolve, 2000));
            }
        }

        if (!accountProof) {
            throw new Error("Failed to get account proof after retries");
        }

        // Tạo proof strings
        const proofStrs = [];

        // Proof string 1: Account proof
        if (!accountProof.accountProof || accountProof.accountProof.length === 0) {
            throw new Error("Account proof is empty");
        }
        const accountProofBytes = Buffer.from(accountProof.accountProof.join('').slice(2), 'hex');
        const accountProofBase64 = accountProofBytes.toString('base64');
        proofStrs.push(accountProofBase64);

        // Proof string 2: Storage proof và transaction data
        if (!accountProof.storageProof || accountProof.storageProof.length === 0) {
            // Nếu không có storage proof, tạo một proof string rỗng
            proofStrs.push("");
        } else {
            const storageProof = accountProof.storageProof[0];
            if (!storageProof || !storageProof.proof) {
                proofStrs.push("");
            } else {
                const storageProofBytes = Buffer.from(storageProof.proof.join('').slice(2), 'hex');
                const storageProofBase64 = storageProofBytes.toString('base64');
                proofStrs.push(storageProofBase64);
            }
        }

        // Tạo final proof object
        const finalProof = {
            ProofStrs: proofStrs,
            BlockHash: block.hash,
            BlockNumber: block.number,
            TransactionHash: txHash,
            TransactionIndex: receipt.transactionIndex,
            From: receipt.from,
            To: receipt.to,
            Value: tx.value.toString(),
            GasUsed: receipt.gasUsed.toString(),
            Status: receipt.status === 1 ? "Success" : "Failed"
        };

        // Lưu proof vào file
        const fs = require('fs');
        fs.writeFileSync('deposit_proof.json', JSON.stringify(finalProof, null, 2));
        
        console.log("Deposit proof đã được lưu vào file deposit_proof.json");
        console.log("\nThông tin proof:");
        console.log("Block Number:", finalProof.BlockNumber);
        console.log("Block Hash:", finalProof.BlockHash);
        console.log("Transaction Hash:", finalProof.TransactionHash);
        console.log("From:", finalProof.From);
        console.log("To:", finalProof.To);
        console.log("Value:", ethers.formatEther(finalProof.Value), "ETH");
        console.log("Gas Used:", finalProof.GasUsed);
        console.log("Status:", finalProof.Status);
        console.log("\nProof Strings:");
        console.log(JSON.stringify(finalProof.ProofStrs, null, 2));

    } catch (error) {
        console.error("Error:", error.message);
        if (error.message.includes("missing trie node")) {
            console.error("\nLỗi này xảy ra vì node không có đủ dữ liệu state trie.");
            console.error("Hãy thử các giải pháp sau:");
            console.error("1. Sử dụng một full node hoặc archive node");
            console.error("2. Đảm bảo node đã sync đầy đủ đến block chứa transaction");
            console.error("3. Nếu đang dùng local node, hãy đợi node sync xong");
        }
    }
}

main()
    .then(() => process.exit(0))
    .catch((error) => {
        console.error(error);
        process.exit(1);
    }); 
