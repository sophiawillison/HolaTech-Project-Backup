#!/usr/bin/env bash
## create tmux session and detach
tmux new -d -s beacon0
tmux new -d -s beacon1
tmux new -d -s beacon2
tmux new -d -s beacon3
tmux new -d -s fullnode
tmux new -d -s shard00
tmux new -d -s shard01
tmux new -d -s shard02
tmux new -d -s shard03
tmux new -d -s shard10
tmux new -d -s shard11
tmux new -d -s shard12
tmux new -d -s shard13

