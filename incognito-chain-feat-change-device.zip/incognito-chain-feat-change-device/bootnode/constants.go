package main

const (
	version              = "1.1.0"
	defaultRPCServerPort = 9330
)
