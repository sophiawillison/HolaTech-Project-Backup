package bridgesig

const (
	CBridgeSigSz = 65
	CSKSz        = 32
)
