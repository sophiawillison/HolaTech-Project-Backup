package connmanager

import "time"

const (
	intervalDiscoverPeer = 60 * time.Second // in second
)

var (
	relayNode = []string{
		"16Hn1SNtGTsYS7zYBcct4b5Jn5xCzzC8S846Er1kFVUfGRxs1Ht",
	}
)
