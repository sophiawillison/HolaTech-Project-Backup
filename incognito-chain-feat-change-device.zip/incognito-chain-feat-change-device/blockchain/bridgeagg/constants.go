package bridgeagg

const (
	unifiedTokenTriggerPrefix = "unified_token_"
)
