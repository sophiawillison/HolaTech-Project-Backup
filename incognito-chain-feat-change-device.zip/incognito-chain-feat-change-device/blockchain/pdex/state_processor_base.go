package pdex

type stateProcessorBase struct {
}
