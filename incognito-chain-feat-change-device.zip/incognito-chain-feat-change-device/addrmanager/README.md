#Address Manager

Manage connected peer information and storage by interval. When node is started, it look for in data file and load old peer info to connect