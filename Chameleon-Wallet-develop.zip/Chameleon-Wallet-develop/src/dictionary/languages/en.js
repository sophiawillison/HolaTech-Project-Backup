const en = {
  WelcomeTo: 'Welcome to',
  Markets: 'Markets',
  Earn: 'Earn',
  Trade: 'Trade',
  Wallet: 'Wallet',
  Apps: 'Apps',
  More: 'More',
  SorryError: 'We sincerely apologize for this incident',
  ErrorCode: 'Error code',
  ExperienceFastAndPrivateTradingForYou: 'Experience fast and private trading for you',
  EnterSecretPhrase: 'Enter secret phrase',
  ImportAnExisting: 'Import an existing wallet or create a new one',
  RestoreFromSecretPharse: 'Restore from secret phrase',
  CreateNewAccount: 'Create a new account',

};

export default en;
