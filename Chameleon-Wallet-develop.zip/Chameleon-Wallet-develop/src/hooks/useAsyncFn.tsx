import useAsyncFn from 'react-use/lib/useAsyncFn';

/**
 * @link https://github.com/streamich/react-use/blob/master/docs/useAsyncFn.md
 */

export {useAsyncFn};
export default useAsyncFn;
