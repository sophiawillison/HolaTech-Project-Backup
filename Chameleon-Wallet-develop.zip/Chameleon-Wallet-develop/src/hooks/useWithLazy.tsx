import { LoadingContainer } from '@src/components/core';
import React, { useEffect, useMemo, useState } from 'react';
import { InteractionManager } from 'react-native';

const useWithLazy = (props: { shouldLazy?: boolean }) => {
    const { shouldLazy = true } = props;
    if (!shouldLazy) return null;
    const [hidden, setHidden] = useState(true);
    const EmptyView = useMemo(
        () => (
            <LoadingContainer />
        ),
        [],
    );

    useEffect(() => {
        InteractionManager.runAfterInteractions(() => {
            setTimeout(() => {
                setHidden(false);
            }, 200);
        });
    }, []);

    if (hidden) return EmptyView;
    return null;
};

export default useWithLazy;
