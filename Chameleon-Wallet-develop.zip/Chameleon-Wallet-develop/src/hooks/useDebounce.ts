import useDebounce from "react-use/lib/useDebounce";

/**
 * @link https://github.com/streamich/react-use/blob/master/docs/useDebounce.md
 */
export default useDebounce;
