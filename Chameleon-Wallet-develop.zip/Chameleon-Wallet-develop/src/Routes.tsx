import React, {memo, useCallback, useEffect, useState} from 'react';
import {
  AppState,
  AppStateStatus,
  Linking,
  StatusBar,
  StyleSheet,
  View,
} from 'react-native';

import {DefaultTheme, NavigationContainer} from '@react-navigation/native';
import {createStackNavigator, TransitionPresets} from '@react-navigation/stack';
import ErrorBoundary from 'react-native-error-boundary';
import {SafeAreaProvider} from 'react-native-safe-area-context';
import SplashScreen from 'react-native-splash-screen';
import {LoadingContainer} from './components/core';
import {ErrorBoundaryScreen} from './components/ErrorBoundary/ErrorBoundary';
import {AuthProvider, useAuth} from './context/AuthContext';
import {WithdrawHistory} from './models/dexHistory';
import {ROUTE_NAMES} from './router';
import {navigateToAddPin, navigationRef} from './router/NavigationServices';
import {SplashNavigator} from './router/navigators/SplashNavigator';
import {TabBarNavigator} from './router/navigators/TabBarNavigator';
import AddPinScreen from './screens/AddPin';
import BackupKeys from './screens/BackupKeys';
import Community from './screens/Community';
import ConvertToUnifiedToken from './screens/ConvertToUnifiedToken';
import ConvertToUnifiedTokenInfo from './screens/ConvertToUnifiedToken/ConvertToUnifiedTokenInfo';
import ProcessConvertToUnifiedToken from './screens/ConvertToUnifiedToken/ProcessConvertToUnifiedToken';
import FollowToken from './screens/FollowToken';
import AddressBook, {
  AddressBookForm,
  SelectNetworkName,
} from './screens/AddressBook';
import InitImportMasterKeyScreen from './screens/InitImportMasterKey';
import InitMasterKeyScreen from './screens/InitMasterKey';
import InitMasterKeyPhraseScreen from './screens/InitMasterKeyPhrase';
import InitVerifyPassphraseScreen from './screens/InitVerifyPassphrase';
import KeysExplainedScreen from './screens/KeysExplained/KeyExplainedScreen';
import {
  Contribute,
  ContributeConfirm,
  CreatePool,
  CreatePoolConfirm,
  RemovePool,
  RemovePoolConfirm,
} from './screens/Liquidity';
import {
  ContributeHistoryDetail,
  LiquidityHistories,
  RemoveLPDetail,
  WithdrawFeeLPDetail,
} from './screens/LiquidityHistories';
import MarketScreen from './screens/Market/MarketScreen';
import MarketSearchCoinsScreen from './screens/MarketSearchCoins/MarketSearchCoinsScreen';
import MasterKeysScreen from './screens/MasterKeys/MasterKeysScreen';
import {MoreScreen} from './screens/More';
import NewsScreen from './screens/News/NewsScreen';
import {NFTTokenScreen} from './screens/NFTToken';
import {OrderLimitDetail} from './screens/OrderLimit';
import OrderLimitScreen from './screens/OrderLimit/OrderLimitScreen';
import QrCodeScannerScreen from './screens/QRCodeScannerScreen/QrCodeScannerScreen';
import Receipt from './screens/Receipt';
import RefillPRVModal from './screens/RefillPRV/RefillPRV.Modal';
import SelectAccountScreen from './screens/SelectAccount/SelectAccountScreen';
import {SelectTokenTrade} from './screens/SelectToken';
import SelectTokenModal from './screens/SelectToken/SelectTokenModal';
import KeychainHome from './screens/Setting/Keychain/Keychain.home';
import ShieldRefund from './screens/Shield/ShieldRefund';
import ShieldScreen from './screens/Shield/ShieldScreen';
import {
  Staking,
  StakingDetail,
  StakingHistories,
  StakingHistoryDetail,
  StakingMoreCoins,
  StakingMoreConfirm,
  StakingMoreInput,
  StakingWithdrawCoins,
  StakingWithdrawInvest,
  StakingWithdrawReward,
} from './screens/Staking';
import StandByScreen from './screens/StandBy/StandByScreen';
import SelectTokenScreen from './screens/Swap/SelectToken/SelectTokenScreen';
import SwapOrderDetail from './screens/Swap/Swap.orderDetail';
import {CoinInfoScreen} from './screens/Wallet/CoinInfo';
import {WalletDetailScreen} from './screens/Wallet/Detail';
import {TxHistoryDetail} from './screens/Wallet/History';
import WhyShieldScreen from './screens/WhyShield/WhyShieldScreen';
import {
  getCurrentRouteName,
  setCurrentRouteName,
} from './services/RouteNameService';
import {useThemeName} from './store';
import {useSelector} from './store/getStore';
import {setWaitingPin} from './store/pin';
import {loadPin} from './store/pin/functions';
import {getSettings} from './store/settings/functions';
import {sleep} from './utils';
import NetworkSettingScreen from './screens/NetworkSetting/NetworkSettingScreen';
// import WebViewScreen from './screens/WebView/WebViewScreen';

const RootStack = createStackNavigator();
const MainStack = createStackNavigator();

const MainNavigator = () => {
  return (
    <MainStack.Navigator
      initialRouteName={ROUTE_NAMES.MainTabBar}
      screenOptions={{
        headerShown: false,
      }}>
      {/* HomeRoutes */}
      <MainStack.Screen
        name={ROUTE_NAMES.MainTabBar}
        component={TabBarNavigator}
      />
      <MainStack.Screen name={ROUTE_NAMES.More} component={MoreScreen} />
      <MainStack.Screen name={ROUTE_NAMES.Market} component={MarketScreen} />
      {/*masterKeyRoutes  */}
      <MainStack.Group>
        <MainStack.Screen name={ROUTE_NAMES.AddPin} component={AddPinScreen} />
        <MainStack.Screen
          name={ROUTE_NAMES.MasterKeys}
          component={MasterKeysScreen}
        />
        <MainStack.Screen
          name={ROUTE_NAMES.ImportMasterKey}
          component={InitImportMasterKeyScreen}
        />
        <MainStack.Screen
          name={ROUTE_NAMES.CreateMasterKey}
          component={InitMasterKeyScreen}
        />
        <MainStack.Screen
          name={ROUTE_NAMES.MasterKeyPhrase}
          component={InitMasterKeyPhraseScreen}
        />
        <MainStack.Screen
          name={ROUTE_NAMES.VerifyPassphrase}
          component={InitVerifyPassphraseScreen}
        />
        <MainStack.Screen
          name={ROUTE_NAMES.KeysExplained}
          component={KeysExplainedScreen}
        />
      </MainStack.Group>
      {/* end masterKeyRoutes */}
      <MainStack.Screen name={ROUTE_NAMES.Shield} component={ShieldScreen} />
      <MainStack.Screen
        name={ROUTE_NAMES.WhyShield}
        component={WhyShieldScreen}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.SelectAccount}
        component={SelectAccountScreen}
      />
      <MainStack.Screen name={ROUTE_NAMES.Keychain} component={KeychainHome} />
      <MainStack.Screen
        name={ROUTE_NAMES.MarketSearchCoins}
        component={MarketSearchCoinsScreen}
      />
      <MainStack.Screen name={ROUTE_NAMES.News} component={NewsScreen} />
      <MainStack.Screen
        name={ROUTE_NAMES.CoinInfo}
        component={CoinInfoScreen}
      />
      <MainStack.Screen name={ROUTE_NAMES.Community} component={Community} />
      <MainStack.Screen name={ROUTE_NAMES.Standby} component={StandByScreen} />
      <MainStack.Screen
        name={ROUTE_NAMES.OrderLimit}
        component={OrderLimitScreen}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.NFTToken}
        component={NFTTokenScreen}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.WalletDetail}
        component={WalletDetailScreen}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.TxHistoryDetail}
        component={TxHistoryDetail}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.ShieldRefund}
        component={ShieldRefund}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.FollowToken}
        component={FollowToken}
      />
      {/* <MainStack.Screen
        name={ROUTE_NAMES.ShieldGenQRCode}
        component={ShieldGenQRCode}
      /> */}
      <MainStack.Screen
        name={ROUTE_NAMES.ContributePool}
        component={Contribute}
      />
      <MainStack.Screen name={ROUTE_NAMES.CreatePool} component={CreatePool} />
      <MainStack.Screen name={ROUTE_NAMES.RemovePool} component={RemovePool} />
      <MainStack.Screen
        name={ROUTE_NAMES.ContributeConfirm}
        component={ContributeConfirm}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.CreatePoolConfirm}
        component={CreatePoolConfirm}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.RemovePoolConfirm}
        component={RemovePoolConfirm}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.OrderLimitDetail}
        component={OrderLimitDetail}
      />
      <MainStack.Screen name={ROUTE_NAMES.Receipt} component={Receipt} />
      <MainStack.Screen
        name={ROUTE_NAMES.AddressBook}
        component={AddressBook}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.AddressBookForm}
        component={AddressBookForm}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.SelectNetworkName}
        component={SelectNetworkName}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.LiquidityHistories}
        component={LiquidityHistories}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.ContributeHistoryDetail}
        component={ContributeHistoryDetail}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.RemoveLPDetail}
        component={RemoveLPDetail}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.WithdrawFeeLPDetail}
        component={WithdrawFeeLPDetail}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.SelectTokenScreen}
        component={SelectTokenScreen}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.SelectTokenModal}
        component={SelectTokenModal}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.SelectTokenTrade}
        component={SelectTokenTrade}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.ConvertToUnifiedToken}
        component={ConvertToUnifiedToken}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.ConvertToUnifiedTokenInfo}
        component={ConvertToUnifiedTokenInfo}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.ProcessConvertToUnifiedToken}
        component={ProcessConvertToUnifiedToken}
      />
      <MainStack.Screen name={ROUTE_NAMES.BackupKeys} component={BackupKeys} />
      {/* Staking */}
      <MainStack.Screen name={ROUTE_NAMES.Staking} component={Staking} />
      <MainStack.Screen
        name={ROUTE_NAMES.StakingMoreInput}
        component={StakingMoreInput}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.StakingMoreCoins}
        component={StakingMoreCoins}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.StakingDetail}
        component={StakingDetail}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.StakingMoreConfirm}
        component={StakingMoreConfirm}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.StakingWithdrawCoins}
        component={StakingWithdrawCoins}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.StakingWithdrawInvest}
        component={StakingWithdrawInvest}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.StakingWithdrawReward}
        component={StakingWithdrawReward}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.StakingHistories}
        component={StakingHistories}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.StakingHistoryDetail}
        component={StakingHistoryDetail}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.OrderSwapDetail}
        component={SwapOrderDetail}
      />
      <MainStack.Screen
        name={ROUTE_NAMES.NetworkSetting}
        component={NetworkSettingScreen}
      />
    </MainStack.Navigator>
  );
};

const MainTabBar = memo(() => {
  const pinState = useSelector(state => state?.pin);
  const {pin, authen, loading, waiting} = pinState;
  const currentRouteName = getCurrentRouteName();

  const [mounted, setMounted] = useState(false);

  const handleLoadPin = useCallback(async () => await loadPin(), []);

  const handleAppStateChange = useCallback(
    (nextAppState: AppStateStatus) => {
      if (mounted) {
        if (nextAppState === 'background') {
          if (pin && !WithdrawHistory.withdrawing) {
            navigateToAddPin({action: 'login'});
            setWaitingPin(false);
          }
          if (WithdrawHistory.withdrawing) {
            setWaitingPin(true);
          }
        }
      }
    },
    [pinState, mounted],
  );

  useEffect(() => {
    if (pin && !authen && currentRouteName !== ROUTE_NAMES.Setting) {
      navigateToAddPin({action: 'login'});
    }
  }, [pin]);

  useEffect(() => {
    const appStateListener = AppState.addEventListener(
      'change',
      handleAppStateChange,
    );
    setMounted(true);
    return () => {
      setMounted(false);
      appStateListener.remove();
    };
  }, [pinState]);

  useEffect(() => {
    handleLoadPin();
  }, []);

  if (loading) {
    return <LoadingContainer />;
  }

  return (
    <>
      <MainNavigator />
      <RefillPRVModal />
    </>
  );
});

const urlHandler = async ({url}: {url: string}) => {
  try {
    return;
  } catch (error) {
    console.log('error urlHandler ', error);
  }
  return;
};

const Routes = () => {
  const themeName = useThemeName();
  const {isLogin} = useAuth();

  useEffect(() => {
    let a: any = undefined;
    let isMounted = true;

    const getUrlAsync = async () => {
      try {
        const url = await Linking.getInitialURL();
        if (url && isMounted) {
          sleep(0.5).then(() => urlHandler({url}));
        }
      } catch (error) {
        console.error(
          'An error occurred while getting the initial URL:',
          error,
        );
        setTimeout(() => {
          if (isMounted) {
            Linking.getInitialURL()
              .then(url => {
                if (url) {
                  sleep(0.5).then(() => urlHandler({url}));
                }
              })
              .catch(err =>
                console.error(
                  'An error occurred on retrying to get the initial URL:',
                  err,
                ),
              );
          }
        }, 2000); // Retry after 2 seconds
      }
    };

    getUrlAsync();

    setTimeout(() => {
      a = Linking.addEventListener('url', urlHandler);
    }, 2000);

    return () => {
      isMounted = false;
      a && a.remove();
    };
  }, []);

  const onStateChange = useCallback(() => {
    const previousRouteName = getCurrentRouteName();
    // @ts-ignore
    const currentRouteName = navigationRef.current?.getCurrentRoute()?.name;

    if (currentRouteName && previousRouteName !== currentRouteName) {
      // analytics().setCurrentScreen(currentRouteName);
      setCurrentRouteName(currentRouteName);
    }
  }, []);

  return (
    <SafeAreaProvider>
      <NavigationContainer
        ref={navigationRef}
        onStateChange={onStateChange}
        onReady={() => SplashScreen.hide()}
        theme={{
          ...DefaultTheme,
          colors: {
            ...DefaultTheme.colors,
          },
        }}>
        <RootStack.Navigator
          initialRouteName={'MainHome'}
          screenOptions={{
            headerShown: false,
            ...TransitionPresets.SlideFromRightIOS,
          }}>
          {!isLogin ? (
            <RootStack.Screen name={'MainHome'} component={MainTabBar} />
          ) : (
            <RootStack.Screen name={'Splash'} component={SplashNavigator} />
          )}
          <RootStack.Screen
            name={'QRCodeScanner'}
            component={QrCodeScannerScreen}
          />
        </RootStack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
};

const _Route = () => {
  const CustomFallback = useCallback(
    (props: {error: Error; resetError: Function}) => {
      return <ErrorBoundaryScreen {...props} isTabBarMode={false} name={''} />;
    },
    [],
  );

  useEffect(() => {
    getSettings();
  }, []);

  return (
    <ErrorBoundary FallbackComponent={CustomFallback}>
      <View style={styles.container}>
        <StatusBar
          barStyle="dark-content"
          translucent
          backgroundColor="transparent"
        />
        <AuthProvider>
          <Routes />
        </AuthProvider>
      </View>
    </ErrorBoundary>
  );
};
export default _Route;

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
});
