import CopiableText from './CopiableText';

export { default as CopiableTextDefault } from './CopiableText.default';

export default CopiableText;
