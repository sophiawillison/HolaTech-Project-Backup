import React from 'react';

export const useTokenList = (): [boolean, () => void] => {
  const [toggleUnVerified, setToggleUnVerified] = React.useState<boolean>(false);
  const onToggleUnVerifiedTokens = () => setToggleUnVerified(!toggleUnVerified);
  return [toggleUnVerified, onToggleUnVerifiedTokens];
};
