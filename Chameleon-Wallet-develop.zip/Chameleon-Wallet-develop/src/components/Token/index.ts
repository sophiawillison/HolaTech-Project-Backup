export { default as withTokenVerified } from './Token.enhanceVerified';
