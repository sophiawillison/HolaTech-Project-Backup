import React from "react";

import { useSelector } from "@src/store/getStore";
import { decimalDigitsSelector } from "@src/store/setting/selectors";
import { NormalText } from "../core/NormalText/NormalText";
import { styled } from "./Token.styled";
import ActivityIndicator from "../core/ActivityIndicator";
import { formatAmount } from "@src/utils/token";

export const Amount = props => {
  const {
    amount = 0,
    pDecimals = 0,
    symbol = '',
    customStyle = null,
    showSymbol = true,
    isGettingBalance = false,
    showGettingBalance = false,
    hasPSymbol = false,
    stylePSymbol = null,
    containerStyle = null,
    size = 'small',
    hideBalance = false,
    fromBalance = false,
    ellipsizeMode = 'tail',
    rightIcon = null,
  } = props;
  const decimalDigits = useSelector(decimalDigitsSelector);
  const shouldShowGettingBalance = isGettingBalance || showGettingBalance;
  if (shouldShowGettingBalance) {
    return <ActivityIndicator size={size} />;
  }

  let amountWithDecimalDigits = formatAmount(
    1,
    amount,
    pDecimals,
    pDecimals,
    decimalDigits,
    false,
  );

  return (
    <NormalText
      text={
        hideBalance
          ? fromBalance
            ? '•••••••'
            : `••• ${showSymbol ? symbol : ''}`
          : `${amountWithDecimalDigits} ${showSymbol ? symbol : ''}`
      }
      hasPSymbol={hideBalance ? false : hasPSymbol}
      stylePSymbol={stylePSymbol}
      containerStyle={containerStyle}
      ellipsizeMode={ellipsizeMode}
      showBalance={!hideBalance}
      rightIcon={rightIcon}
    />
  );
};