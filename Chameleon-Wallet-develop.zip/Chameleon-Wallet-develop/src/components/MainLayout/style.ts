import { StyleSheet } from 'react-native';

export default StyleSheet.create({
  content: {
    // paddingTop: 24,
    backgroundColor: 'transparent',
  },
  noPaddingStyle: {
    marginHorizontal: -25,
  },
  paddingHeader: {
    marginHorizontal: 25,
  },
});
