import { ModalConfirm } from './ModalConfirm';

export default ModalConfirm;
