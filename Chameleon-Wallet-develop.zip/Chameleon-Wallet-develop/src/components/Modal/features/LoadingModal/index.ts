import LoadingModal from './LoadingModal';

export default LoadingModal;
