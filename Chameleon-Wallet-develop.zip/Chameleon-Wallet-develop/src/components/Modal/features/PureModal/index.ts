import PureModal from './PureModal';

export default PureModal;
export { default as PureModalContent } from './PureModal.content';
