import Modal from './modal';

export default Modal;
