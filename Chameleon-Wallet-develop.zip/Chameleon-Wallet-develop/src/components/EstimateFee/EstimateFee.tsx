import { createForm, InputField, validator } from '@src/components/core/reduxForm';
import { GENERAL } from '@src/constants/elements';
import formatUtils from '@utils/format';
import { generateTestId } from '@utils/misc';
import React, { useEffect, useMemo, useState } from 'react';
import { TouchableOpacity } from 'react-native';
import { Field } from 'redux-form';
import Modal from '../Modal';
import { Text, View } from '../core';
import ActivityIndicator from '../core/ActivityIndicator';
import Button from '../core/Button';
import styles from './styles';
import { toHumanAmount } from '@src/utils/common';
import { convertUtils } from '@src/utils/convert';

const getAnotherTypeOfFee = (types, feeUnitByTokenId) => {
  return types?.find(t => t?.tokenId !== feeUnitByTokenId);
};

const feeValidator = [
  validator.required(),
  validator.number(),
  validator.largerThan(0)
];

interface EstimateFeeProps {
  minFee?: number;
  isGettingFee?: boolean;
  onRetry?: () => void;
  onNewFeeData: (data: any) => void;
  rfChange: () => void;
  rfDestroy: (formName: string) => void;
  setUserFee: (fee: number) => void;
  feePDecimals?: number;
  types?: any[];
  estimateFeeData: any;
  feeText?: string | React.ReactElement;
  estimateErrorMsg?: string;
  style?: any;
}

const formName = 'changeFee';
const Form = createForm(formName, {
  destroyOnUnmount: false
});

const EstimateFee = (props: EstimateFeeProps) => {
  const {
    minFee,
    isGettingFee = false,
    onRetry,
    onNewFeeData,
    rfChange,
    rfDestroy,
    setUserFee,
    feePDecimals,
    types = [],
    estimateFeeData,
    feeText,
    estimateErrorMsg,
    style
  } = props;

  const [isRetrying, setIsRetrying] = useState(false);
  const [anotherFee, setAnotherFee] = useState(null);
  const [isShowChangeFeeInput, setIsShowChangeFeeInput] = useState(false);
  const [minFeeValidator, setMinFeeValidator] = useState(null);


  const _anotherFee = useMemo(() => {
    if (estimateErrorMsg) {
      return getAnotherTypeOfFee(types, estimateFeeData?.feeUnitByTokenId);
    }
    return null;
  }, [estimateErrorMsg, types, estimateFeeData?.feeUnitByTokenId]);

  const _minFeeValidator = useMemo(() => {
    if (minFee) {
      const convertedMinFee = toHumanAmount(minFee, feePDecimals);
      const convertedMinFeeStr = formatUtils.toFixed(convertedMinFee, feePDecimals);
      return validator.minValue(convertedMinFee, {
        message: `Must be at least ${convertedMinFeeStr} ${estimateFeeData?.feeUnit}`
      });
    }
    return undefined;
  }, [minFee, feePDecimals, estimateFeeData?.feeUnit]);

  useEffect(() => {
    return () => {
      const { rfDestroy } = props;
      rfDestroy(formName);
    }
  }, [minFee, feePDecimals, feeUnit]);

  const onChangeNewFee = (values) => {
    const { onNewFeeData, feePDecimals, setUserFee } = props;
    const { fee } = values;

    // convert fee to nano fee
    const originalFee = convertUtils.toOriginalAmount(fee, feePDecimals);

    if (typeof onNewFeeData === 'function' && typeof originalFee === 'number') {
      setIsShowChangeFeeInput(false)

      // update new custom fee
      onNewFeeData({ fee: originalFee });

      // save custom fee, use later
      setUserFee(originalFee);
    }
  }

  const onResetFee = () => {
    const { onNewFeeData, setUserFee, minFee } = props;
    if (typeof onNewFeeData === 'function' && typeof minFee === 'number') {
      onNewFeeData({ fee: minFee });
      setUserFee(minFee);
    }

    setIsShowChangeFeeInput(false);
  }

  const handleSelectFeeType = (type) => {
    const { onNewFeeData, estimateFeeData } = props;
    if (typeof onNewFeeData === 'function' && estimateFeeData?.feeUnitByTokenId !== type?.tokenId) {
      onNewFeeData({ feeUnitByTokenId: type?.tokenId, feeUnit: type?.symbol, fee: null });
    }
  }

  const _onRetry = (anotherFee) => {
    if (anotherFee) {
      handleSelectFeeType(anotherFee);
      return;
    }

    const { onRetry } = props;
    const delay = new Promise(r => {
      setTimeout(() => r(), 500);
    });
    setIsRetrying(true);
    Promise.all([onRetry?.(), delay])
      .finally(() => {
        setIsRetrying(false);
      });
  }

  const renderChangeFee = () => {
    const { estimateFeeData: { feeUnit }, minFee } = props;

    return (
      <Modal animationType="fade" transparent visible={isShowChangeFeeInput} containerStyle={styles.changeFeeModal}>
        <Form style={styles.changeFeeForm}>
          {({ handleSubmit }) => (
            <>
              <Text style={styles.feeTextTitle}>
                Pay a higher fee to the network for faster transaction speeds
              </Text>
              <View style={styles.feeInputWrapper}>
                <Field
                  component={InputField}
                  componentProps={{
                    keyboardType: 'decimal-pad'
                  }}
                  prependView={
                    <Text>{feeUnit}</Text>
                  }
                  name='fee'
                  placeholder='Enter new fee'
                  style={styles.changeFeeInput}
                  validate={[
                    ...feeValidator,
                    ...minFeeValidator ? [minFeeValidator] : []
                  ]}
                />
              </View>
              <View style={styles.changeFeeBtnGroup}>
                <Button style={[styles.changeFeeSubmitBtn]} title='Pay this fee' onPress={handleSubmit(onChangeNewFee)} />
                <Button titleStyle={styles.changeFeeText} style={styles.changeFeeBtn} title={minFee > 0 ? 'Pay default fee' : 'Close'} onPress={onResetFee} />
              </View>
            </>
          )}
        </Form>
      </Modal>
    );
  }

  const renderFeeText = () => {
    const { feeText } = props;

    if (typeof feeText === 'string') {
      return <Text {...generateTestId(GENERAL.NETWORK_FEE)}>{feeText}</Text>;
    } else if (React.isValidElement(feeText)) {
      return feeText;
    }

    return null;
  }

  const { feeUnitByTokenId, fee } = estimateFeeData || {};

  return (
    <View style={[styles.container, style]}>
      <View style={styles.box}>
        <View>
          <View style={styles.feeTypeGroup}>
            {
              types?.map((type, index) => {
                const { symbol, tokenId } = type;
                const onPress = () => handleSelectFeeType(type);
                const isHighlight = feeUnitByTokenId === tokenId;
                return (
                  <TouchableOpacity
                    key={tokenId}
                    onPress={onPress}
                    style={
                      [
                        styles.feeType,
                        index === 0 && styles.feeTypeFirst,
                        isHighlight && styles.feeTypeHighlight
                      ]
                    }
                  >
                    <Text
                      style={
                        [
                          styles.feeTypeText,
                          isHighlight && styles.feeTypeTextHighlight
                        ]
                      }
                    >
                      Use {symbol}
                    </Text>
                  </TouchableOpacity>
                );
              })
            }
          </View>
        </View>

        {estimateErrorMsg
          ? (
            <View style={styles.errorBox}>
              <Text style={styles.errorText}>{estimateErrorMsg}</Text>
              <Button onPress={() => _onRetry(anotherFee)} style={styles.retryBtn} title={anotherFee ? `Try ${anotherFee?.symbol}` : 'Try again'} isAsync isLoading={isRetrying} />
            </View>
          )
          : (
            <View style={styles.rateContainer}>
              {
                !Number.isFinite(fee) && !isGettingFee
                  ? <Text style={styles.rateText}>- Transaction fee will be calculated here -</Text>
                  : (
                    isGettingFee ?
                      <ActivityIndicator /> :
                      (
                        <>
                          <View style={styles.feeTextContainer}>
                            <Text style={styles.feeTextTitle}>{'You\'ll pay'}</Text>
                            {renderFeeText()}
                          </View>
                        </>
                      )
                  )
              }
            </View>
          )
        }
        {renderChangeFee()}
      </View>
    </View>
  );
}


export default EstimateFee;
