import { MESSAGES } from '@screens/Dex/constants';
import accountService from '@services/wallet/accountService';
import { CONSTANT_COMMONS } from '@src/constants';
import { CustomError, ExHandler } from '@src/services/exception';
import { getAccountByName } from '@src/store/account/selectors';
import { MAX_FEE_PER_TX } from '@src/store/estimateFee/utils';
import { useSelector } from '@src/store/getStore';
import { selectedPrivacy as selectedPrivacySelector } from '@src/store/selectedPrivacy/selectors';
import { walletSelector } from '@src/store/wallet/selectors';
import formatUtil from '@src/utils/format';
import React, { useCallback, useEffect, useState } from 'react';
import EstimateFee from './EstimateFee';

const CACHED_FEE = {
  // token_id_for_use.token_id_for_fee.total_amount_of_the_token: fee
};
const DEFAULT_TYPES = {
  tokenId: CONSTANT_COMMONS.PRV_TOKEN_ID,
  symbol: CONSTANT_COMMONS.CRYPTO_SYMBOL.PRV,
};

interface TokenType {
  tokenId: string;
  symbol: string;
}

interface EstimateFeeData {
  fee?: number | string;
  feeUnit?: string;
  feeUnitByTokenId?: string;
}

interface EstimateFeeContainerProps {
  accountName: string;
  estimateFeeData: EstimateFeeData;
  onNewFeeData: (data: any) => void;
  selectedPrivacy?: any;
  amount?: number | string | null;
  toAddress?: string | null;
  style?: any;
  types?: TokenType[];
  feeText?: string | null;
  onEstimateFailed?: (() => void) | null;
  dexToken?: any;
  dexBalance?: number;
  multiply?: number;
}

const getTypes = (types?: TokenType[]) => {
  const _types: { [key: string]: TokenType } = {};
  _types[DEFAULT_TYPES.tokenId] = DEFAULT_TYPES;
  types?.forEach(type => {
    type?.tokenId && (_types[type.tokenId] = type);
  });

  return Object.values(_types);
};

const EstimateFeeContainer = (props: EstimateFeeContainerProps) => {
  const {
    accountName,
    estimateFeeData,
    onNewFeeData,
    selectedPrivacy = null,
    amount = null,
    toAddress = null,
    style = null,
    types = [
      {
        tokenId: CONSTANT_COMMONS.PRV_TOKEN_ID,
        symbol: CONSTANT_COMMONS.CRYPTO_SYMBOL.PRV,
      },
    ],
    feeText = null,
    onEstimateFailed = null,
    dexToken = null,
    dexBalance = 0,
    multiply = 1,
  } = props;

  const finalSelectedPrivacy = selectedPrivacy || useSelector(selectedPrivacySelector);
  const account = useSelector(getAccountByName)(accountName);
  const wallet = useSelector(walletSelector);

  const [isGettingFee, setIsGettingFee] = useState(false);
  const [estimateErrorMsg, setEstimateErrorMsg] = useState(null);
  const [userFee, setUserFee] = useState(undefined);
  const [minFee, setMinFee] = useState(undefined);
  const [processedTypes, setProcessedTypes] = useState(getTypes(types));

  const onSetUserFee = useCallback(fee => {
    if (Number.isInteger(fee)) {
      setUserFee(fee);
    }
  }, []);

  const handleNewFeeData = useCallback(({ fee, feeUnitByTokenId, feeUnit }: { fee?: number, feeUnitByTokenId?: string, feeUnit?: string } = {}) => {

    // clear err msg and show loading if user changes type of fee
    if (feeUnitByTokenId) {
      setEstimateErrorMsg(null);
      setIsGettingFee(true);
    }

    if (typeof onNewFeeData === 'function') {
      const newEstimateFeeData = {
        ...(estimateFeeData || {}),
        ...(fee !== undefined ? { fee } : {}),
        ...(feeUnitByTokenId !== undefined ? { feeUnitByTokenId } : {}),
        ...(feeUnit !== undefined ? { feeUnit } : {}),
      };

      onNewFeeData({
        ...newEstimateFeeData,
        isUseTokenFee:
          newEstimateFeeData?.feeUnitByTokenId !==
          CONSTANT_COMMONS.PRV_TOKEN_ID,
      });
    }
  }, []);

  const selectDefaultFeeType = useCallback(() => {
    // select a type as default, priority: selectedPrivacy > PRV > first type

    const defaultType =
      processedTypes.find(t => t.tokenId === finalSelectedPrivacy.tokenId) ||
      processedTypes.find(t => t.tokenId === CONSTANT_COMMONS.PRV_TOKEN_ID) ||
      processedTypes[0];

    if (defaultType) {
      handleNewFeeData({
        feeUnitByTokenId: defaultType.tokenId,
        feeUnit: defaultType.symbol,
      });
    }
  }, [processedTypes, finalSelectedPrivacy, handleNewFeeData]);

  const feeGuarantor = useCallback(async (handleGetFeeFn, sendTokenId, feeTokenId, amount) => {
    let fee;
    const key = `${sendTokenId}.${feeTokenId}.${amount}`;
    try {
      const cachedFee = Number(CACHED_FEE[key]) || 0;

      if (cachedFee) {
        // has cached fee, return it and try to re-estimate for later (dont need to wait for it)
        fee = cachedFee;
        handleGetFeeFn().then(fee => {
          // cache latest fee
          CACHED_FEE[key] = Number(fee) > cachedFee ? fee : cachedFee;
        });
      } else {
        // has a no cached fee, do estimate
        fee = await handleGetFeeFn();
      }

      if (Number.isInteger(fee) && fee > 0) {
        return fee;
      } else {
        throw new Error('Fee is invalid, use default fee instead');
      }
    } catch {
      return MAX_FEE_PER_TX;
    } finally {
      // cache it
      CACHED_FEE[key] = fee;
    }
  }, []);

  const _estimateFeeForMainCrypto = async () => {
    return 100;
  };

  const _estimateFeeForToken = async () => {
    return 100;
  };

  const _handleEstimateTokenFee = async () => {
    return 100;
  };

  const handleEstimateFee = useCallback(async () => {
    let fee;
    let minFee;
    try {
      const {
        amount,
        toAddress,
        estimateFeeData: { feeUnitByTokenId },
        multiply,
      } = props;

      if (!amount || !toAddress || !finalSelectedPrivacy) {
        return;
      }

      setIsGettingFee(true);
      setEstimateErrorMsg(null);
      handleNewFeeData({ fee: null });

      if (
        feeUnitByTokenId === selectedPrivacy?.tokenId &&
        selectedPrivacy.isToken
      ) {
        // estimate fee in pToken [pETH, pBTC, ...]
        fee = await feeGuarantor(
          _handleEstimateTokenFee,
          selectedPrivacy?.tokenId,
          feeUnitByTokenId,
          selectedPrivacy?.amount,
        );
      } else if (feeUnitByTokenId === CONSTANT_COMMONS.PRV_TOKEN_ID) {
        // estimate fee in PRV
        if (selectedPrivacy?.isToken) {
          fee = await feeGuarantor(
            _estimateFeeForToken,
            selectedPrivacy?.tokenId,
            feeUnitByTokenId,
            selectedPrivacy?.amount,
          );
        }
        if (selectedPrivacy?.isMainCrypto) {
          fee = await feeGuarantor(
            _estimateFeeForMainCrypto,
            selectedPrivacy?.tokenId,
            feeUnitByTokenId,
            selectedPrivacy?.amount,
          );
        }
      } else {
        throw new CustomError(
          'estimate_fee_does_not_support_type_of_fee'
        );
      }

      fee = fee * multiply;
      minFee = fee;
      fee = userFee > fee ? userFee : fee;

      setEstimateErrorMsg(null)

      return fee;
    } catch (e) {
      const {
        onEstimateFailed,
        estimateFeeData: { feeUnit },
      } = props;
      if (accountService.isNotEnoughCoinErrorCode(e)) {
        setEstimateErrorMsg(MESSAGES.PENDING_TRANSACTIONS);
        onEstimateFailed?.();
      } else {
        setEstimateErrorMsg(
          new ExHandler(
            e,
            `Something went wrong while estimating ${feeUnit} fee for this transactions, please try again.`,
          ).message,
        );
        onEstimateFailed?.();
      }
      fee = null;
      minFee = null;
    } finally {
      setIsGettingFee(false);
      setMinFee(minFee);
      handleNewFeeData({ fee });
    }
  }, [props, account, handleNewFeeData, feeGuarantor, userFee]);

  const getPDecimals = useCallback((selectedPrivacy: any, defaultFeeTokenId: string) => {
    if (defaultFeeTokenId === CONSTANT_COMMONS.PRV_TOKEN_ID) {
      return CONSTANT_COMMONS.DECIMALS.MAIN_CRYPTO_CURRENCY;
    }

    if (defaultFeeTokenId === selectedPrivacy?.tokenId) {
      return selectedPrivacy?.pDecimals;
    }

    return null;
  }, []);

  // Mount effect - equivalent to componentDidMount
  useEffect(() => {
    selectDefaultFeeType();
  }, []); // Empty dependency array means this runs once on mount

  // Update effect - equivalent to componentDidUpdate logic
  useEffect(() => {
    handleEstimateFee();
  }, [amount, estimateFeeData?.feeUnitByTokenId]); // Runs when amount or feeUnitByTokenId changes

  // Effect to select default type if not selected
  useEffect(() => {
    if (!estimateFeeData?.feeUnitByTokenId) {
      selectDefaultFeeType();
    }
  }, [estimateFeeData?.feeUnitByTokenId, selectDefaultFeeType]); // Runs when feeUnitByTokenId changes

  const { feeUnitByTokenId, fee, feeUnit } = estimateFeeData || {};
  const feePDecimals = getPDecimals(selectedPrivacy, feeUnitByTokenId);
  const txt =
    feeText ??
    (fee && `${formatUtil.amountFull(fee, feePDecimals)} ${feeUnit}`);

  if (account && selectedPrivacy && types.length) {
    return (
      <EstimateFee
        {...props}
        isGettingFee={isGettingFee}
        estimateErrorMsg={estimateErrorMsg}
        onRetry={handleEstimateFee}
        onNewFeeData={handleNewFeeData}
        setUserFee={setUserFee}
        minFee={minFee}
        style={style}
        types={types}
        feeText={txt}
        feePDecimals={feePDecimals}
      />
    );
  }

  return null;
}



export default EstimateFeeContainer