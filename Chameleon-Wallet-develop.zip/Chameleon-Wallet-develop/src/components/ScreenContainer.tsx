import { ImageBackground, ScrollView } from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import Header from "./Header/Header";

interface ScreenContainerProps {
    style?: any;
    children: React.ReactNode;
    isScroll?: boolean;
    headerTitle?: string;
    containerStyle?: any;
    headerStyle?: any;
}

export const ScreenContainer = ({ style, children, isScroll = false, headerTitle, containerStyle, headerStyle }: ScreenContainerProps) => {
    const insets = useSafeAreaInsets();

    const content = isScroll ? (
        <ScrollView contentContainerStyle={[{ flexGrow: 1 }, containerStyle]}
            showsVerticalScrollIndicator={false}>
            {children}
        </ScrollView>
    ) : (
        children
    );

    return (
        <ImageBackground
            source={require('../assets/images/BackgroundGradient.png')}
            style={{ flex: 1, paddingTop: insets.top, paddingBottom: insets.bottom, paddingLeft: insets.left, paddingRight: insets.right, ...style }}
        >   
            {!!headerTitle && <Header title={headerTitle} style={headerStyle} />}
            {content}
        </ImageBackground>
    );
};