import React from 'react';
import PropTypes from 'prop-types';
import {View, Button} from '@src/components/core';
import {withNavigation} from 'react-navigation';
import {backupStyle} from './style';
import {navigateToBackupKeys} from '@src/router/NavigationServices';

const SendReceiveGroup = ({navigation}) => {
  const goToBackup = () => {
    navigateToBackupKeys();
  };

  return (
    <View style={backupStyle.container}>
      <Button
        title="Back up"
        onPress={goToBackup}
        style={backupStyle.button}
        titleStyle={backupStyle.buttonText}
      />
    </View>
  );
};

SendReceiveGroup.propTypes = {
  navigation: PropTypes.object.isRequired,
};

export default withNavigation(SendReceiveGroup);
