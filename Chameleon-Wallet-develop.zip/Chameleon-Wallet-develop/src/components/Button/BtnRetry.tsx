import React from 'react';
import { RetryIcon } from '@src/components/Icons';
import { TouchableOpacity } from '@src/components/core';
import { TouchableOpacityProps } from 'react-native';

const BtnRetry = (props: TouchableOpacityProps) => {
  return (
    <TouchableOpacity {...props}>
      <RetryIcon />
    </TouchableOpacity>
  );
};

export default React.memo(BtnRetry);
