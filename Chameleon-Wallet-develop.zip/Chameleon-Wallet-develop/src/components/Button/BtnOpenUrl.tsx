import React from 'react';
import { StyleProp, ViewStyle, TextStyle, TouchableOpacityProps } from 'react-native';
import { TouchableOpacity } from '@src/components/core';
import IconOpenUrl from '../Icons/icon.openUrl';

interface BtnOpenUrlProps extends TouchableOpacityProps {
  containerStyle?: StyleProp<ViewStyle>;
  iconStyle?: StyleProp<TextStyle>;
}

const BtnOpenUrl = (props: BtnOpenUrlProps) => {
  const { containerStyle, iconStyle, ...rest } = props;
  return (
    <TouchableOpacity {...rest}>
      <IconOpenUrl containerStyle={containerStyle} style={iconStyle} />
    </TouchableOpacity>
  );
};


export default BtnOpenUrl;
