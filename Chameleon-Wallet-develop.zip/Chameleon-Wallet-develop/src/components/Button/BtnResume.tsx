import { Text, TouchableOpacity } from '@src/components/core';
import { COLORS, FONTS } from '@src/styles';
import React from 'react';
import { StyleSheet, TouchableOpacityProps } from 'react-native';

const style = StyleSheet.create({
  text: {
    ...FONTS.STYLE.medium,
    fontSize: 15,
    color: COLORS.black,
  },
});

interface BtnResumeProps extends TouchableOpacityProps {
  resuming?: boolean;
}

const BtnResume = (props: BtnResumeProps) => {
  const {resuming, ...rest} = props;
  return (
    <TouchableOpacity {...rest}>
      <Text style={style.text}>{`Resume${resuming ? '...' : ''}`}</Text>
    </TouchableOpacity>
  );
};

export default React.memo(BtnResume);
