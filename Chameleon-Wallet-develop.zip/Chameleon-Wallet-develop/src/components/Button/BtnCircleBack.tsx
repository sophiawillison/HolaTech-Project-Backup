import {CircleBack} from '@src/components/Icons';
import React, {memo} from 'react';
import {
  StyleSheet,
  TouchableOpacity,
  TouchableOpacityProps,
} from 'react-native';

interface BtnCircleBackProps extends TouchableOpacityProps {
  btnStyle?: any;
}

const BtnCircleBack = memo((props: BtnCircleBackProps) => {
  const {btnStyle} = props;
  
  // Ensure proper z-index and pointer events for absolute positioning
  const combinedStyle = [
    styles.btnStyle, 
    btnStyle,
  ];
  
  return (
    <TouchableOpacity 
      style={combinedStyle} 
      activeOpacity={0.5}
      {...props}
    >
      <CircleBack />
    </TouchableOpacity>
  );
});

export default BtnCircleBack;
const styles = StyleSheet.create({
  btnStyle: {
    width: 34,
    height: 34,
    justifyContent: 'center',
    alignItems: 'center', // Added for better icon centering
    position: 'absolute',
    left: 16,
    zIndex: 1000,
  },
});
