import React from 'react';
import { TouchableOpacity } from '@src/components/core';
import { Image } from 'react-native';

const srcFast = require('../../assets/images/icons/fast.png');
const srcFast2x = require('../../assets/images/icons/fast_2x.png');

interface BtnFastProps {
  onPress: (fast2x: boolean) => void;
  defaultValue?: boolean;
}

const BtnFast = (props: BtnFastProps) => {
  const { onPress, defaultValue = false, ...rest } = props;
  const [fast2x, shouldFast2x] = React.useState(defaultValue);
  const handlePressBtnFast = async () => {
    const _fast2x = !fast2x;
    shouldFast2x(_fast2x);
    if (typeof onPress === 'function') {
      onPress(_fast2x);
    }
  };
  return (
    <TouchableOpacity onPress={handlePressBtnFast} {...rest}>
      <Image
        source={fast2x ? srcFast2x : srcFast}
        style={{
          width: 24,
          height: 18,
        }}
      />
    </TouchableOpacity>
  );
};
export default BtnFast;
