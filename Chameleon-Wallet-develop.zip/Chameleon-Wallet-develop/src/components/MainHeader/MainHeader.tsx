import React, {memo} from 'react';
import {StyleSheet, Text, View} from 'react-native';
import {Avatar, IconButton} from 'react-native-paper';

const user = {
    name: 'Eleanor Pena',
    avatar: require('../../assets/avatar.png'), // Replace with your avatar asset
  };
  

const MainHeader = memo(() => {
  return (
    <View style={styles.headerBg}>
      <View style={styles.headerRow}>
        <Avatar.Image size={30} source={user.avatar} />
        <Text style={styles.userName}>{user.name}</Text>
        <View style={styles.bellWrapper}>
          <IconButton
            icon="bell-outline"
            size={24}
            iconColor="#111"
            style={styles.bellIcon}
          />
          <View style={styles.badge} />
        </View>
      </View>
    </View>
  );
});

export default MainHeader;

const styles = StyleSheet.create({
  headerBg: {
    paddingTop: 12,
    paddingHorizontal: 16,
    borderBottomLeftRadius: 32,
    borderBottomRightRadius: 32,
  },
  headerRow: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
  },
  userName: {
    flex: 1,
    fontSize: 16,
    fontWeight: 'bold',
    color: '#111',
    marginLeft: 16,
  },
  bellWrapper: {
    marginLeft: 16,
  },
  bellIcon: {
    backgroundColor: 'rgba(255, 255, 255, 0.5)',
    borderRadius: 24,
  },
  badge: {
    position: 'absolute',
    top: 6,
    right: 6,
    width: 16,
    height: 16,
    borderRadius: 8,
    backgroundColor: '#FF5252',
    borderWidth: 2,
    borderColor: '#fff',
  },
});
