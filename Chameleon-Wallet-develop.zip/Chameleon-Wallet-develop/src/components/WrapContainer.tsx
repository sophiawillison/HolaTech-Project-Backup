import React, { useMemo } from 'react';
import { ImageBackground, StyleSheet, ViewStyle } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';

interface ContainerViewProps {
  children?: React.ReactNode;
  style?: ViewStyle;
}

const WrapContainer: React.FC<ContainerViewProps> = ({ children, style }) => {
  const insets = useSafeAreaInsets();

  const containerStyles = useMemo(() => ({
    flex: 1,
    paddingTop: insets.top,
    paddingBottom: insets.bottom,
    paddingHorizontal: insets.left,
  }), [])

  return (
    <ImageBackground source={require('../assets/images/Background.png')} style={[containerStyles, style]}>
      {children}
    </ImageBackground>
  );
};

export default WrapContainer;

