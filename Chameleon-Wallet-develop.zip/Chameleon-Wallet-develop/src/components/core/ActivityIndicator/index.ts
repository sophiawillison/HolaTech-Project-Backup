export { default } from './Component';
