export { default as FlexView } from './Component';
export { default as FlexView2 } from './FlexView2';