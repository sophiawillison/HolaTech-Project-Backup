import React from 'react';
import Button from '../Button';
import styles from './style';
import _ from 'lodash';
import { ButtonProps } from '../Button/Component';

interface RoundCornerButtonSolidProps extends ButtonProps {} 

const RoundCornerButtonSolid = ({ style, titleStyle, title = '', isLoading, disabled, ...props }: RoundCornerButtonSolidProps) => (
  <Button
    style={[styles.buttonSolid, style]}
    titleStyle={[styles.buttonSolidTitle, titleStyle]}
    title={title}
    isLoading={isLoading}
    disabled={isLoading || disabled}
    isAsync={isLoading}
    {...props}
  />
);
export default RoundCornerButtonSolid;
