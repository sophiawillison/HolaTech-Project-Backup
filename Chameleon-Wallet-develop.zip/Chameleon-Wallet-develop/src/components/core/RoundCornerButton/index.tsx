import React from 'react';
import Button from '../Button';
import styles from './style';
import { TouchableOpacityProps } from 'react-native';
import { COLORS } from '@src/styles';
import { useTheme } from 'styled-components/native';

interface RoundCornerButtonProps extends TouchableOpacityProps {
  style?: object;
  titleStyle?: object;
  title?: string;
  isLoading?: boolean;
  disabled?: boolean;
}

const RoundCornerButton = ({
  style,
  titleStyle,
  title = '',
  isLoading,
  disabled,
  ...props
}: RoundCornerButtonProps) => {
  const theme = useTheme();
  return (
    <Button
      style={[styles.button, style, disabled ? { backgroundColor: theme.disabled } : {}]}
      titleStyle={[styles.buttonTitle, titleStyle, disabled ? { color: theme.grey2 } : {}]}
      title={title}
      isLoading={isLoading}
      disabled={isLoading || disabled}
      isAsync={isLoading}
      {...props}
    />
  )
};
export default RoundCornerButton;
