import React, {memo} from 'react';
import {Text, View} from 'react-native';
import styled from './AmountGroup.styled';
import ActivityIndicator from '../ActivityIndicator';

interface AmountGroupProps {
  title?: string;
  amountStr: string;
  subAmountStr: string;
  loading: boolean;
}

const AmountGroup = ({
  title = 'Total reward',
  amountStr,
  subAmountStr,
  loading,
}: AmountGroupProps) => {
  return (
    <View style={styled.wrapper}>
      <Text style={styled.title}>{title}</Text>
      {loading ? (
        <View style={styled.loading}>
          <ActivityIndicator />
        </View>
      ) : (
        <>
          <Text style={styled.baseAmount}>{amountStr}</Text>
          <Text style={styled.compareAmount}>{subAmountStr}</Text>
        </>
      )}
    </View>
  );
};

export default memo(AmountGroup);
