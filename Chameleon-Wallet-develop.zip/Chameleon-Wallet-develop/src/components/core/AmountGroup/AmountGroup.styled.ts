import { StyleSheet } from 'react-native';
import { FONTS, COLORS } from '@src/styles';

export default StyleSheet.create({
  wrapper: {
    maxWidth: '80%'
  },
  title: {
    fontFamily: FONTS.NAME.regular,
    fontSize: FONTS.SIZE.small,
    lineHeight: FONTS.SIZE.small + 3,
    color: COLORS.lightGrey33,
    textAlign: 'center',
  },
  baseAmount: {
    fontFamily: FONTS.NAME.medium,
    fontSize: FONTS.SIZE.superLarge,
    lineHeight: FONTS.SIZE.superLarge + 12,
    color: COLORS.black,
    textAlign: 'center',
  },
  compareAmount: {
    fontFamily: FONTS.NAME.regular,
    fontSize: FONTS.SIZE.small,
    lineHeight: FONTS.SIZE.small + 3,
    color: COLORS.black1,
    textAlign: 'center'
  },
  loading: {
    marginTop: 15
  }
});
