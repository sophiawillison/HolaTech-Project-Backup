import { FONTS } from '@src/styles';
import { replaceCommaText } from '@utils/string';
import debounce from 'lodash/debounce';
import React from 'react';
import { Platform, TextInputProps } from 'react-native';
import styled, { useTheme } from 'styled-components/native';

const Container = styled.View`
  background-color: #FFFFFF;
  border-radius: 8px;
  flex-direction: row;
  align-items: center;
  padding: 6px 12px;
`;

const StyledInput = styled.TextInput`
  flex: 1;
  color: ${({ theme }) => theme.text1};
  fontFamily: ${FONTS.NAME.medium};
  font-family: ${FONTS.NAME.regular};
  font-size: 16px;
  height: 52px;
`;

// A custom hook for position of cursor's text input on Android OS
const useCursorInputTextForAndroid = ({ value, onBlur, onFocus }: { value: string, onBlur: () => void, onFocus: () => void }) => {
  const [selection, setSelection] = React.useState(undefined);
  const [isFocused, setIsFocused] = React.useState(false);
  const handleSetSelectionForAnroid = React.useCallback(
    (selection, value) => {
      if (Platform.OS === 'android' && !!value) {
        setSelection(selection);
        setTimeout(() => {
          setSelection(undefined);
        }, 100);
      }
    },
    [value, selection],
  );
  const handleOnBlur = () => {
    setIsFocused(false);
    if (typeof onBlur === 'function') { 
      onBlur();
    }
    handleSetSelectionForAnroid({ start: 0, end: 0 }, value);
  };

  const handleOnFocus = async () => {
    setIsFocused(true);
    if (typeof onFocus === 'function') {
      onFocus();
    }
    handleSetSelectionForAnroid(
      { start: value?.length, end: value?.length },
      value,
    );
  };
  const debounceHandleSelection = debounce(
    React.useCallback(value => {
      handleSetSelectionForAnroid({ start: 0, end: 0 }, value);
    }, []),
    100,
  );
  React.useEffect(() => {
    if (isFocused || !value) {
      return;
    }
    debounceHandleSelection(value);
  }, [value, isFocused]);
  return {
    selection,
    setSelection,
    handleOnBlur,
    handleOnFocus,
  };
};

interface BaseTextInputProps extends TextInputProps {
  rightComponent?: React.ReactNode;
}

export const BaseTextInput = (props: BaseTextInputProps) => {
  const {
    style,
    editable = true,
    onFocus,
    onBlur,
    onChangeText,
    value,
    keyboardType,
    rightComponent,
    ...rest
  } = props;
  const theme = useTheme();
  const { selection, setSelection, handleOnBlur, handleOnFocus } =
    useCursorInputTextForAndroid({ value, onBlur, onFocus });
    
  const handleChangeText = text => {
    setSelection(undefined);
    if (typeof onChangeText === 'function') {
      const newText = replaceCommaText({ text, keyboardType });
      onChangeText(newText);
    }
  };
  return (
    <Container>
      <StyledInput
        placeholderTextColor={theme.text10}
        returnKeyType="done"
        autoCorrect={false}
        spellCheck={false}
        keyboardType={keyboardType}
        editable={editable}
        style={style}
        value={value}
        selection={
          Platform.OS === 'android' && !!selection ? selection : undefined
        }
        onBlur={handleOnBlur}
        onFocus={handleOnFocus}
        onChangeText={handleChangeText}
        {...rest}
      />
      {rightComponent}
    </Container>
  );
};
