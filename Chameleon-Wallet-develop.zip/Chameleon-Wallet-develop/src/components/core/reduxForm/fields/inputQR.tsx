import BtnScanQrCode from '@src/components/Button/BtnScanQrCode';
import { TextInput, TouchableOpacity, View } from '@src/components/core';
import { AddressBookIcon } from '@src/components/Icons';
import { SEND } from '@src/constants/elements';
import { generateTestId } from '@utils/misc';
import React from 'react';
import { Alert, StyleSheet } from 'react-native';
import createField from './createField';

const styled = StyleSheet.create({
    prepend: {
        flexDirection: 'row',
        alignItems: 'center',
        height: '100%',
    },
    line: {
        width: 1,
        height: 20,
        marginHorizontal: 5,
    },
    btn: {
        width: 32,
        height: '100%',
        alignItems: 'center',
        justifyContent: 'center',
    },
});

const getAddress = (text) => {
    if (text && typeof text === 'string') {
        let indexSpec = text.indexOf(':');
        if (indexSpec != -1) {
            return text.substring(indexSpec + 1, text.length);
        } else {
            return text;
        }
    } else {
        return '';
    }
};
interface RenderCustomFieldProps {
    input: any;
    onOpenAddressBook: () => void;
    showNavAddrBook: boolean;
    oldVersion: boolean;
    shouldStandardized: boolean;
}

const renderCustomField = ({
    input = null,
    onOpenAddressBook = () => { },
    showNavAddrBook = false,
    oldVersion = false,
    shouldStandardized = false,
    ...props
}: RenderCustomFieldProps) => {
    const { onChange, onBlur, onFocus, value, ...rest } = input;
    return (
        <TextInput
            {...{ ...props, ...rest }}
            onChangeText={(t) => input.onChange(t)}
            onBlur={onBlur}
            onFocus={onFocus}
            returnKeyType="done"
            oldVersion={oldVersion && oldVersion}
            defaultValue={value}
            prependView={(
                <View style={styled.prepend}>
                    {showNavAddrBook && (
                        <>
                            <TouchableOpacity
                                style={styled.btn}
                                onPress={onOpenAddressBook}
                                {...generateTestId(SEND.ADDRESS_BOOK_ICON)}
                            >
                                <AddressBookIcon />
                            </TouchableOpacity>
                            <View style={styled.line} />
                        </>
                    )}
                    <BtnScanQrCode
                        style={styled.btn}
                        onPress={() => {
                            // TODO
                            Alert.alert('WIP');
                            // openQrScanner((data) => {
                            //     let res = getAddress(data);
                            //     if (shouldStandardized) {
                            //         res = standardizedAddress(res);
                            //     }
                            //     input.onChange(res);
                            // });
                        }}
                    />
                </View>
            )}
        />
    );
};



const InputQRField = createField({
    fieldName: 'InputQRField',
    render: renderCustomField,
});

export default InputQRField;
