export {default} from './Component';
