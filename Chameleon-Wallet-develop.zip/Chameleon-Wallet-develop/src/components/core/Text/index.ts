export * from './Component';
export * from './Text3';
export * from './Text4';
export * from './Text5';
export * from './Text6';
export * from './Text7';
export * from './Text8';
export * from './Text9';
