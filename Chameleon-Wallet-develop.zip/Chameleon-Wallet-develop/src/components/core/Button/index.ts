export { default, ButtonExtension } from './Component';
export * from './Button';
