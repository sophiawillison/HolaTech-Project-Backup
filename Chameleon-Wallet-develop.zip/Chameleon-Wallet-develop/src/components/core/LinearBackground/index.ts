import LinearBackground from './LinearBackground';

export default LinearBackground; 