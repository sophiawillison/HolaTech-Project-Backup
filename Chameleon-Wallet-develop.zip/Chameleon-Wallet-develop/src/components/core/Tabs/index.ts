export {default} from './Tabs';
export {default as Tab} from './Tabs.tab';
export {default as Tabs1} from './Tabs.tabs1';
