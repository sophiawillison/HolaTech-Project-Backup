import { StyleSheet } from 'react-native';

const style = StyleSheet.create({
  root: {
    flexGrow: 1,
  },
  content: {
    paddingBottom: 60,
  }
});

export default style;
