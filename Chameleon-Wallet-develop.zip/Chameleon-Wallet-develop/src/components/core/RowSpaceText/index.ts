export { default } from './RowSpaceText';
