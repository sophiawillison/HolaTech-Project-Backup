import {StyleSheet} from 'react-native';
import {FONTS} from '@src/styles';

export const styled = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    height: 46,
  },
});

export const styledHeaderTitle = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    flexDirection: 'row',
    alignSelf: 'center',
  },
  title: {
    color: '#000',
    fontSize: 18,
    fontFamily: FONTS.NAME.semibold,
    textAlign: 'center',
    flex: 1,
  },
  searchStyled: {
    textTransform: 'none',
    maxWidth: '100%',
  },
  containerTitle: {
    textAlign: 'center',
    flex: 1,
  },
});
