import React from 'react';

export const HeaderContext = React.createContext({});
export const HeaderTitleContext = React.createContext({});
