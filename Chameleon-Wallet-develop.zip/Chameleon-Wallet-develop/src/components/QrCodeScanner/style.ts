// import { StyleSheet } from 'react-native';

// export default StyleSheet.create({
//   container: {
//     flexDirection: 'column',
//     alignItems: 'center',
//     justifyContent: 'center',

//   },
//   desc: {
//     textAlign: 'center',
//     marginBottom: 20,
//   }
// });
