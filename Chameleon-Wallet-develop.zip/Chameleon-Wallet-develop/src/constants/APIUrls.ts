
export const API_URLS = {

    
  SYSTEM_CONFIGS: '/system/configs',



}
