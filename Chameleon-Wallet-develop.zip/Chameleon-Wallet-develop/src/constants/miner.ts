export const CONSTANT_MINER = {
  PRODUCT_NAME: 'The Miner',
  VIRTUAL_PRODUCT_NAME: 'Miner Virtual',
  PRODUCT_TYPE :'MINER',
  MAX_QUATITY :[1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
};
export const DEVICES={
  MINER_TYPE:'MINER',
  VIRTUAL_TYPE:'VIRTUAL',
  CLOUD_TYPE:'CLOUD',
};
