export const CONSTANTS_CHAINS = {
  BLOCK_TIME: 40, // seconds
};
