declare module '@env' {
  export const API_BASE: string;
}
