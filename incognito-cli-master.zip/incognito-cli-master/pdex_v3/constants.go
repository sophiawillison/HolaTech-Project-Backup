package pdex_v3

const (
	TradeDirectionSell0 = iota
)

const (
	MaxPaths      = 5
	BaseAmplifier = 10000
)
