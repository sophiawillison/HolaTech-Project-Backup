#!/usr/bin/env bash
## create tmux session and detach
tmux new -d -s highway1
tmux new -d -s highway2
