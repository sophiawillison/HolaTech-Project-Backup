#!/usr/bin/env bash
rm -rf mem.prof
