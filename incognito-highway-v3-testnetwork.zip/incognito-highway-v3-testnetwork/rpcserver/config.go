package rpcserver

type RpcServerConfig struct {
	Port int
}
